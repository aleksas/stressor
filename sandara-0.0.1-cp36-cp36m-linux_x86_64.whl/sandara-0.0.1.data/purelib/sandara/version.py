# -*- coding: utf-8 -*-

VERSION = '0.0.1'
RELEASE = '1'
